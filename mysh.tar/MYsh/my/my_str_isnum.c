/*
** my_str_isnum.c for my_str_isnum in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:04:52 2013 loisel_k
** Last update Wed Oct  9 12:06:40 2013 loisel_k
*/

int		my_str_isnum(char *str)
{
  return (0);
}
