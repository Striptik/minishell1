/*
** my_showmem.c for my_showmem in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:13:17 2013 loisel_k
** Last update Wed Oct  9 12:14:18 2013 loisel_k
*/

int		my_showmem(char *str, int size)
{
  return (size);
}
