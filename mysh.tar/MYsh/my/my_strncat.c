/*
** my_strncat.c for my_strncat in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:16:29 2013 loisel_k
** Last update Wed Oct  9 12:17:21 2013 loisel_k
*/

char		*my_strncat(char *dest, char *src, int nb)
{
  return (dest);
}
