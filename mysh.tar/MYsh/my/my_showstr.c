/*
** my_showstr.c for my_showstr in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:11:15 2013 loisel_k
** Last update Wed Oct  9 12:12:22 2013 loisel_k
*/

int		my_showstr(char *str)
{
  return (0);
}
